$(function() {
  $('.slick-v1').slick({
    slidesToShow: 1,
    infinite: true,
    prevArrow: '<span data-role="none" class="slick-v1-prev" aria-label="Previous"></span>',
    nextArrow: '<span data-role="none" class="slick-v1-next" aria-label="Next"></span>'
  });
});